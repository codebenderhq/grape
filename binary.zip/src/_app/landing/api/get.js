
/**
 * @name indexAPI
 * This is a test function
 */


const hello =  async () => {

    console.log(request.method)
    return {status:200, msg: 'BAD'}
}

return hello()




 
 