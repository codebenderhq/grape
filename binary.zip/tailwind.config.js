module.exports = {
    content: [
    "./src/app/**/*.{html,js,svg,css}",
    "./src/_app/**/*.{html,js,svg,css}",
    "./src/app/**/**/*.{html,js,svg,css}",
    "./src/**/*.{html,css,svg}",
    "./src/app/*.{html,css}"
 
],
    theme: {
        extend: {},
    },
    plugins: [],
    // darkMode: 'class',
}